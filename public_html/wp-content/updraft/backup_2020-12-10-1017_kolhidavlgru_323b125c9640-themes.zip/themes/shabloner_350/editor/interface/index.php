<?php include('head.php'); ?>


<?php include($_APP['view']); ?>
  
  
<?php include('footer.php'); ?>
