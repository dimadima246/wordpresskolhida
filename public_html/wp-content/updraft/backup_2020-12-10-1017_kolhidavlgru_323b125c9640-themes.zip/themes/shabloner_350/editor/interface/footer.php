
</div>

<div id="dialogs"></div>

<script>
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});

</script>


			</div>

		</section><!-- #content end -->

		
		<!-- Footer
		============================================= -->
		<footer id="footer" class="dark">
			<!-- Copyrights
			============================================= -->
			<div id="copyrights">

				<div class="container clearfix">

					<div class="col_half copyright-links ">
						Все права защищены &copy; 2018 - <?=date('Y')?>
					</div>

					<div class="col_half col_last tright">
						<div class="fright clearfix">
							<div class="copyrights-menu copyright-links nobottommargin">
								<a href="<?=SHTTP_PATH?>?utm_source=editor">Шаблонер</a>
							</div>
						</div>
					</div>

				</div>

			</div><!-- #copyrights end -->

		</footer><!-- #footer end -->
		
		
		
	</div><!-- #wrapper end -->

	<!-- Go To Top
	============================================= -->
	<div id="gotoTop" class="icon-angle-up"></div>

	
	<!-- Footer Scripts
	============================================= -->
	<script src="<?=HTTP_PATH?>/interface/js/functions.js"></script>

</body>
</html>