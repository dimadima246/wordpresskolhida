<!-- slider -->

<!-- Обложка с непрозрачным блоком текста #56 (133337) -->
<div data-id="133337" id="block_133337" class="block_schema block_133337 area_slider">
<?php $block_schema_id = 133337; $block_id = 56; $block_cat_id = 2;  include('/home/d/dima246/kolhida/public_html/wp-content/themes/shabloner_350/editor/sources/preview_edit.php'); ?><?php include(get_template_directory()."/blocks/slider_56_133337.php") ?><?php include('/home/d/dima246/kolhida/public_html/wp-content/themes/shabloner_350/editor/sources/preview_edit_bottom.php'); ?>

</div>

<!-- / block_133337 -->
