		<!-- Footer
		============================================= -->
		<footer id="footer" class="dark  footer_5" >
		<div class="overfill" style=""></div>
		
			<!-- Copyrights
			============================================= -->
			<div id="copyrights">

				<div class="container clearfix center">

				<span class="editable block_133340 item-option_3 field_footer_text"><?=$settings['site_name']?> © <?=date('Y')?> | <a target="_blank" href="http://shabloner.ru/" title="Дизайн сайта">Шаблонер</a> | Все права защищены</span>

				</div>

			</div><!-- #copyrights end -->

		</footer><!-- #footer end -->
