<div class="section   nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        <div class="heading-block divcenter center" style="max-width: 600px">
<h2 class="notransform t600 mb-2 editable block_133350 item-option_138574 field_title" style="">Наша команда</h2>
<p class="editable block_133350 item-option_1 field_text">Краткое описание</p>
</div>


<div class="team_members">
    
	<div class="col_one_fourth ">

		<div class="team">
			
			<div class="team-image">
				<img src="<?=$theme_path?>/files/ct_block_133350_item_84877_481265.jpg?_1607584055">
			</div>
			
			<div class="team-desc">
				<div class="team-title">
				<h4 class="editable block_133350 item item-field_title item-option_771056 item-int_84877">Василий</h4>
				<span class="editable block_133350 item item-field_text item-option_987048 item-int_84877">Руководитель</span>
				</div>
				
				<a href="http://vk.com/user" class="social-icon inline-block si-small si-light si-rounded si-vk">
					<i class="icon-vk"></i>
					<i class="icon-vk"></i>
				</a>
				
				
				<a href="#" class="social-icon inline-block si-small si-light si-rounded si-instagram">
					<i class="icon-instagram"></i>
					<i class="icon-instagram"></i>
				</a>
				
			</div>
		</div>

	</div>
    
    
	<div class="col_one_fourth ">

		<div class="team">
			
			<div class="team-image">
				<img src="<?=$theme_path?>/files/ct_block_133350_item_35599_481265.jpg?_1607584055">
			</div>
			
			<div class="team-desc">
				<div class="team-title">
				<h4 class="editable block_133350 item item-field_title item-option_771056 item-int_35599">Семен</h4>
				<span class="editable block_133350 item item-field_text item-option_987048 item-int_35599">Программист</span>
				</div>
				
				<a href="http://vk.com/user" class="social-icon inline-block si-small si-light si-rounded si-vk">
					<i class="icon-vk"></i>
					<i class="icon-vk"></i>
				</a>
				
				
				<a href="#" class="social-icon inline-block si-small si-light si-rounded si-instagram">
					<i class="icon-instagram"></i>
					<i class="icon-instagram"></i>
				</a>
				
			</div>
		</div>

	</div>
    
    
	<div class="col_one_fourth ">

		<div class="team">
			
			<div class="team-image">
				<img src="<?=$theme_path?>/files/ct_block_133350_item_76855_481265.jpg?_1607584055">
			</div>
			
			<div class="team-desc">
				<div class="team-title">
				<h4 class="editable block_133350 item item-field_title item-option_771056 item-int_76855">Ольга</h4>
				<span class="editable block_133350 item item-field_text item-option_987048 item-int_76855">Маркетолог</span>
				</div>
				
				<a href="http://vk.com/user" class="social-icon inline-block si-small si-light si-rounded si-vk">
					<i class="icon-vk"></i>
					<i class="icon-vk"></i>
				</a>
				
				
				<a href="#" class="social-icon inline-block si-small si-light si-rounded si-instagram">
					<i class="icon-instagram"></i>
					<i class="icon-instagram"></i>
				</a>
				
			</div>
		</div>

	</div>
    
    
	<div class="col_one_fourth col_last">

		<div class="team">
			
			<div class="team-image">
				<img src="<?=$theme_path?>/files/ct_block_133350_item_55887_481265.jpg?_1607584055">
			</div>
			
			<div class="team-desc">
				<div class="team-title">
				<h4 class="editable block_133350 item item-field_title item-option_771056 item-int_55887">Петр</h4>
				<span class="editable block_133350 item item-field_text item-option_987048 item-int_55887">Менеджер по продажам</span>
				</div>
				
				<a href="http://vk.com/user" class="social-icon inline-block si-small si-light si-rounded si-vk">
					<i class="icon-vk"></i>
					<i class="icon-vk"></i>
				</a>
				
				
				<a href="#" class="social-icon inline-block si-small si-light si-rounded si-instagram">
					<i class="icon-instagram"></i>
					<i class="icon-instagram"></i>
				</a>
				
			</div>
		</div>

	</div>
    
    
</div>


    
        </div>
    </div>
</div>    
