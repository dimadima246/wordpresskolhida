		<section id="slider" class="cblock-56 slider-element slider-parallax  " style="background: url('<?=$theme_path?>/files/ct_block_133337_image_JiumvPbI.jpg?_1607584179') left 50% top 50%; background-size: cover; height:550px; ">
			<div class="overfill" style="background-color: rgba(0, 0, 0, 0.40);"></div>
			<div class="slider-parallax-inner  z1000">
				<div class="container clearfix">
					<div class="vertical-middle-auto">
					    <div class="caption_block col_half col_last nobottommargin">
    					    <div class="" >
    							<div class="fancy-title title-bottom-border"><h1 class="editable block_133337 item-option_925312 field_title">Заголовок</h1></div>
    							<p class="editable block_133337 item-option_1 field_text">Съешь же ещё этих мягких французских булок да выпей чаю.</p>
    							
    							<p class="lead topmargin-xs"><a href='/o-kompanii' class="button button-rounded button-3d button-3d editable block_133337 item-option_584216 field_button_text">Подробнее</a></p>
    							
    						</div>				
						</div>				

					</div>
				</div>
				
			</div>
		</section>
