<header id="header" class="cv-head-1  no-sticky " style="[style]">

    <div class="container clearfix bottompadding-xs toppadding-xs">

		<!-- Logo
		============================================= -->
			<div id="logo">
			    
			    <div class='logo_desc'>
			    <div class="toppadding-xs" id="site_name"><a href="/"><?=$settings['site_name']?></a></div>
		        <div class="" id="site_description"><?=$settings['site_description']?></div>
			    </div>
			    
			</div><!-- #logo end -->
		
			 
		<div class="btn-holder pull-right media-desktop leftmargin-minier">
		<button type="button"  data-url="<?=$source_folder?>//forms/basic.php" class="dialog_open pull-right button button-rounded button-large  button-3d button-3d" >Обратный звонок</button>
		</div>
			

		<ul class="header-extras">
			<li>
				<i class="i-plain icon-map-marker nomargin color"></i>
				<div class="he-text">
					Адрес
					<span class="text-muted">ул Тверская, 17, офис 738</span>
				</div>
			</li>
			
			<li>
				<i class="i-plain icon-call nomargin color"></i>
				<div class="he-text">
					Телефон
					<span class="text-muted">8 (495) 725 25 25</span>
				</div>
			</li>
			
			 
			
			
		</ul>
		
		
	</div>
	<div id="" class="">

	
		<!-- Primary Navigation
		============================================= -->
<div id="page-menu" class="no-sticky ">

	<div id="page-menu-wrap">

		<div class="container clearfix">

			<nav class="with-arrows">
										<ul>
							<li class="current"><a href="/"><div>Главная</div></a></li>	
							<li><a href="#">О компании</a></li>
							<li><a href="#"><div>Услуги</div></a>
								<ul>
									<li><a href="#"><div>Услуга</div></a></li>
									<li><a href="#"><div>Услуга</div></a></li>
									<li><a href="#"><div>Услуга</div></a></li>
									<li><a href="#"><div>Услуга</div></a></li>
									<li><a href="#"><div>Услуга</div></a></li>
								</ul>
							
							</li>
							<li><a href="#"><div>Отзывы о нас</div></a></li>
							<li><a href="#"><div>Контакты</div></a></li>
						</ul>

			</nav>

			<div id="page-submenu-trigger"><i class="icon-reorder"></i></div>

		</div>

	</div>

</div>
	</div>

</header>