<div class="section   nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        
<div class="heading-block divcenter center" style="max-width: 600px">
<h2 class="notransform t600 mb-2 editable block_133350 item-option_575383 field_title" style="">Наши специалисты</h2>

</div>


<div class="row m-0 dark clearfix" data-height-xs="500" data-height-sm="500" data-height-md="350" data-height-lg="350" data-height-xl="350">


<a href="" class="col-md-4 image_fade border-right" style="background: url('<?=$theme_path?>/files/ct_block_item_133350_231570_3_image.jpg?_1607518562') no-repeat center center / cover;">
<div class="overlay">
<div class="text-overlay">
<div class="text-overlay-title">
<h3 class="editable block_133350 item item-field_title item-option_819515 item-int_231570">Федор Cеменов</h3>
</div>
<div class="text-overlay-meta">
<span class="editable block_133350 item item-field_button_text item-option_1 item-int_231570"></span>
</div>
</div>
</div>
</a>

<a href="/nashi-specialisty" class="col-md-4 image_fade border-right" style="background: url('<?=$theme_path?>/files/ct_block_item_133350_1_3_image.jpg?_1607518562') no-repeat center center / cover;">
<div class="overlay">
<div class="text-overlay">
<div class="text-overlay-title">
<h3 class="editable block_133350 item item-field_title item-option_819515 item-int_1">Алексей Лазарев</h3>
</div>
<div class="text-overlay-meta">
<span class="editable block_133350 item item-field_button_text item-option_1 item-int_1">Подробности &rarr;</span>
</div>
</div>
</div>
</a>

<a href="/nashi-specialisty" class="col-md-4 image_fade border-right" style="background: url('<?=$theme_path?>/files/ct_block_item_133350_2_3_image.jpg?_1607518562') no-repeat center center / cover;">
<div class="overlay">
<div class="text-overlay">
<div class="text-overlay-title">
<h3 class="editable block_133350 item item-field_title item-option_819515 item-int_2">Семен Орлов</h3>
</div>
<div class="text-overlay-meta">
<span class="editable block_133350 item item-field_button_text item-option_1 item-int_2">Подробности &rarr;</span>
</div>
</div>
</div>
</a>

<a href="/nashi-specialisty" class="col-md-4 image_fade border-right" style="background: url('<?=$theme_path?>/files/ct_block_item_133350_3_3_image.jpg?_1607518562') no-repeat center center / cover;">
<div class="overlay">
<div class="text-overlay">
<div class="text-overlay-title">
<h3 class="editable block_133350 item item-field_title item-option_819515 item-int_3">Олег Иванов</h3>
</div>
<div class="text-overlay-meta">
<span class="editable block_133350 item item-field_button_text item-option_1 item-int_3">Подробности &rarr;</span>
</div>
</div>
</div>
</a>

<a href="/nashi-specialisty" class="col-md-4 image_fade border-right" style="background: url('<?=$theme_path?>/files/ct_block_item_133350_4_3_image.jpg?_1607518562') no-repeat center center / cover;">
<div class="overlay">
<div class="text-overlay">
<div class="text-overlay-title">
<h3 class="editable block_133350 item item-field_title item-option_819515 item-int_4">Ольга Лядова</h3>
</div>
<div class="text-overlay-meta">
<span class="editable block_133350 item item-field_button_text item-option_1 item-int_4">Подробности &rarr;</span>
</div>
</div>
</div>
</a>




</div>    
        </div>
    </div>
</div>    
