<section id="slider" class="cblock-47 slider-element slider-parallax swiper_wrapper clearfix " data-loop="false" style="height:700px" >

	<div class="slider-parallax-inner">

		<div class="swiper-container swiper-parent">
			<div class="swiper-wrapper">
			    
				<div class="swiper-slide dark" style="background-image: url('<?=$theme_path?>/files/ct_block_item_133337_628721_6_image.jpg?_1607518394');">
				    <div class="overfill" style="background-color: rgba(0, 0, 0, 0.40);"></div>
					<div class="container clearfix">
						<div class="slider-caption slider-caption-center">
							<h2 class=" editable block_133337 item item-field_title item-option_305679 item-int_628721">Юридические услуги</h2>
							
							<p class="d-none d-sm-block editable block_133337 item item-field_text item-option_5 item-int_628721">Описание акции или другая дополнительная информация</p>
							
							
							
						</div>
					</div>
				</div>
				
				<div class="swiper-slide dark" style="background-image: url('<?=$theme_path?>/files/ct_block_item_133337_1_6_image.jpg?_1607518394');">
				    <div class="overfill" style="background-color: rgba(0, 0, 0, 0.40);"></div>
					<div class="container clearfix">
						<div class="slider-caption slider-caption-center">
							<h2 class=" editable block_133337 item item-field_title item-option_305679 item-int_1">Юридические услуги</h2>
							
							<p class="d-none d-sm-block editable block_133337 item item-field_text item-option_5 item-int_1">Описание акции или другая дополнительная информация</p>
							
							
							
						</div>
					</div>
				</div>
				
				<div class="swiper-slide dark" style="background-image: url('<?=$theme_path?>/files/ct_block_item_133337_2_6_image.jpg?_1607518394');">
				    <div class="overfill" style="background-color: rgba(0, 0, 0, 0.40);"></div>
					<div class="container clearfix">
						<div class="slider-caption slider-caption-center">
							<h2 class=" editable block_133337 item item-field_title item-option_305679 item-int_2">Юридические услуги</h2>
							
							<p class="d-none d-sm-block editable block_133337 item item-field_text item-option_5 item-int_2">Описание акции или другая дополнительная информация</p>
							
							
							
						</div>
					</div>
				</div>
				
				
			</div>
			<div class="slider-arrow-left"><i class="icon-angle-left"></i></div>
			<div class="slider-arrow-right"><i class="icon-angle-right"></i></div>
			<!--<div class="slide-number"><div class="slide-number-current"></div><span>/</span><div class="slide-number-total"></div></div>-->
		</div>

	</div>

</section>
