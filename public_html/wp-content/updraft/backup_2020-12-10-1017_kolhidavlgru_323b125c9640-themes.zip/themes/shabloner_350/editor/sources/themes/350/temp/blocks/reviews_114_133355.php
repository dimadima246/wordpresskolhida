<div class="section nobg  nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        <div class="heading-block divcenter center" style="max-width: 600px">
<h2 class="notransform t600 mb-2 editable block_133355 item-option_971293 field_title" style="">Отзывы</h2>

</div>


<div id="" class="">
    
	<div class="testimonial  bottommargin-sm">
		<div class="testi-image">
			<a href="#"><img src="<?=$theme_path?>/files/ct_block_item_133355_2_2_image.jpeg?_1607518394"></a>
		</div>
		<div class="testi-content">
			<p class="">Работаем с данной фирмой уже довольно давно. Никаких нареканий, одни положительные впечатления. Будем продолжать сотрудничество.</p>
			
			<div class="testi-meta">
				Ольга
			</div>
			
		</div>
	</div>
    
	<div class="testimonial  bottommargin-sm">
		<div class="testi-image">
			<a href="#"><img src="<?=$theme_path?>/files/ct_block_item_133355_1_2_image.png?_1607518394"></a>
		</div>
		<div class="testi-content">
			<p class="">Сайт понравился. Спасибо менеджерам за творческий подход! Буду рекомендовать всем друзьям и близким.</p>
			
			<div class="testi-meta">
				Степан
			</div>
			
		</div>
	</div>
    
	<div class="testimonial  bottommargin-sm">
		<div class="testi-image">
			<a href="#"><img src="<?=$theme_path?>/files/ct_block_item_133355_3_2_image.jpg?_1607518394"></a>
		</div>
		<div class="testi-content">
			<p class="">Сайт просто супер. Ребята молодцы, делают свою работу на высоком уровне. Товары всегда новые, цены вполне доступные. Часто проводятся скидки, акции, что особо радует :) </p>
			
			<div class="testi-meta">
				Аркадий
			</div>
			
		</div>
	</div>
    
</div>
    
        </div>
    </div>
</div>    
