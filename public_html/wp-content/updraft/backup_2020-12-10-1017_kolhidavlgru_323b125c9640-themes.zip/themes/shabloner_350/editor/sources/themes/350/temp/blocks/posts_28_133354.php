<div class="section   nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        
<div class="heading-block divcenter center" style="max-width: 600px">
<h2 class="notransform t600 mb-2 editable block_133354 item-option_233723 field_title" style="">Новости</h2>
</div>


<div id="posts" class="post-grid grid-container grid-3 clearfix" data-layout="fitRows">



	<div class="entry clearfix nobottommargin ">
	    
		
		<div class="entry-image">
			<a href="#"><img class="image_fade" src="http://shabloner.ru/files/mini_image.jpg?_1607584055.jpg?_1607584055"></a>
		</div>
		
		
		<div class="entry-title">
			<h3><a href="#">Заголовок контента</a></h3>
		</div>
		<ul class="entry-meta clearfix">
			<li><i class="icon-calendar3"></i> <?=date('d.m.Y');?></li>
		</ul>
		<div class="entry-content">
			<p class="t300">Джек много работает не играет и становится глупым и скучным. Джек много работает не играет и становится глупым и скучным. </p>
			<a href="#" class="more-link">Читать далее...</a>
		</div>
	</div>
  

</div>    
        </div>
    </div>
</div>    
