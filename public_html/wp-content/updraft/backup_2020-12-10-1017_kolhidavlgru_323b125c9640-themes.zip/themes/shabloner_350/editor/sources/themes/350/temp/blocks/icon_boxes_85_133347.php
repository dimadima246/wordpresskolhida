<div class="section nobg  nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        
<div class="heading-block divcenter center" style="max-width: 600px">
<h2 class="notransform t600 mb-2 editable block_133347 item-option_527715 field_title" style="">Наши преимущества</h2>
<p class="editable block_133347 item-option_1 field_text">Съешь же ещё этих мягких французских булок да выпей чаю.</p>
</div>





<div class="col_one_third  nobottommargin">
	<div class="feature-box fbox-center fbox-border fbox-effect noborder">
		<a href="#">
		    <div class="fbox-icon">
			<i class="icon-line2-earphones-alt"></i>
    		</div>
    		<h3 class="editable block_133347 item item-field_title item-option_977843 item-int_37722">Доступность</h3>
    		<div class="editable block_133347 item item-field_text item-option_3 item-int_37722">Можно выбрать тематическую иконку среди 1350</div>
		</a>
	</div>
</div>


<div class="col_one_third  nobottommargin">
	<div class="feature-box fbox-center fbox-border fbox-effect noborder">
		<a href="#">
		    <div class="fbox-icon">
			<i class="icon-map-marker"></i>
    		</div>
    		<h3 class="editable block_133347 item item-field_title item-option_977843 item-int_1">Удобное расположение</h3>
    		<div class="editable block_133347 item item-field_text item-option_3 item-int_1">Можно выбрать тематическую иконку среди 1350</div>
		</a>
	</div>
</div>


<div class="col_one_third col_last nobottommargin">
	<div class="feature-box fbox-center fbox-border fbox-effect noborder">
		<a href="#">
		    <div class="fbox-icon">
			<i class="icon-like"></i>
    		</div>
    		<h3 class="editable block_133347 item item-field_title item-option_977843 item-int_2">Качество</h3>
    		<div class="editable block_133347 item item-field_text item-option_3 item-int_2">Можно выбрать тематическую иконку среди 1350</div>
		</a>
	</div>
</div>



    
        </div>
    </div>
</div>    
