<div class="section   nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        
<div class="heading-block divcenter center" style="max-width: 600px">
<h2 class="notransform t600 mb-2 editable block_133348 item-option_185008 field_title" style="">Юридическим лицам Все услуги</h2>

</div>





	<div class="col_one_fourth  nobottommargin">
		<div class="feature-box center media-box fbox-bg">
			<div class="fbox-media">
				<a href="/arbitrazhnye-spory"><img class="image_fade" src="<?=$theme_path?>/files/ct_block_item_133348_128042_5_image.jpg?_1607518394"></a>
			</div>
			<div class="fbox-desc">
				<h3 class="editable block_133348 item item-field_title item-option_704264 item-int_128042">Арбитражные споры</h3>
				
				
				<p><a href="/arbitrazhnye-spory" class="btn button button-3d editable block_133348 item item-field_button_text item-option_1 item-int_128042" >Подробности</a></p>
			</div>
		</div>
	</div>

	

	<div class="col_one_fourth  nobottommargin">
		<div class="feature-box center media-box fbox-bg">
			<div class="fbox-media">
				<a href="/iuridicheskoe-soprovozhdenie-tszh-zhsk-uk"><img class="image_fade" src="<?=$theme_path?>/files/ct_block_item_133348_1_5_image.jpg?_1607518394"></a>
			</div>
			<div class="fbox-desc">
				<h3 class="editable block_133348 item item-field_title item-option_704264 item-int_1">Юридическое сопровождение ТСЖ, ЖСК, УК</h3>
				
				
				<p><a href="/iuridicheskoe-soprovozhdenie-tszh-zhsk-uk" class="btn button button-3d editable block_133348 item item-field_button_text item-option_1 item-int_1" >Подробности</a></p>
			</div>
		</div>
	</div>

	

	<div class="col_one_fourth  nobottommargin">
		<div class="feature-box center media-box fbox-bg">
			<div class="fbox-media">
				<a href="/iuridicheskoe-soprovozhdenie-organizacii"><img class="image_fade" src="<?=$theme_path?>/files/ct_block_item_133348_2_5_image.jpg?_1607518394"></a>
			</div>
			<div class="fbox-desc">
				<h3 class="editable block_133348 item item-field_title item-option_704264 item-int_2">Юридическое сопровождение организации</h3>
				
				
				<p><a href="/iuridicheskoe-soprovozhdenie-organizacii" class="btn button button-3d editable block_133348 item item-field_button_text item-option_1 item-int_2" >Подробности</a></p>
			</div>
		</div>
	</div>

	

	<div class="col_one_fourth col_last nobottommargin">
		<div class="feature-box center media-box fbox-bg">
			<div class="fbox-media">
				<a href="/zashita-intellektualnoi-sobstvennosti"><img class="image_fade" src="<?=$theme_path?>/files/ct_block_item_133348_3_5_image.jpg?_1607518394"></a>
			</div>
			<div class="fbox-desc">
				<h3 class="editable block_133348 item item-field_title item-option_704264 item-int_3">Защита интеллектуальной собственности</h3>
				
				
				<p><a href="/zashita-intellektualnoi-sobstvennosti" class="btn button button-3d editable block_133348 item item-field_button_text item-option_1 item-int_3" >Подробности</a></p>
			</div>
		</div>
	</div>

	<div class="clear bottommargin"></div>

	<div class="col_one_fourth  nobottommargin">
		<div class="feature-box center media-box fbox-bg">
			<div class="fbox-media">
				<a href="/nedvizhimost-zemlia"><img class="image_fade" src="<?=$theme_path?>/files/ct_block_item_133348_4_5_image.jpg?_1607518394"></a>
			</div>
			<div class="fbox-desc">
				<h3 class="editable block_133348 item item-field_title item-option_704264 item-int_4">Недвижимость, земля</h3>
				
				
				<p><a href="/nedvizhimost-zemlia" class="btn button button-3d editable block_133348 item item-field_button_text item-option_1 item-int_4" >Подробности</a></p>
			</div>
		</div>
	</div>

	

	<div class="col_one_fourth  nobottommargin">
		<div class="feature-box center media-box fbox-bg">
			<div class="fbox-media">
				<a href="/zashita-delovoi-reputacii"><img class="image_fade" src="<?=$theme_path?>/files/ct_block_item_133348_5_5_image.jpg?_1607518394"></a>
			</div>
			<div class="fbox-desc">
				<h3 class="editable block_133348 item item-field_title item-option_704264 item-int_5">Защита деловой репутации</h3>
				
				
				<p><a href="/zashita-delovoi-reputacii" class="btn button button-3d editable block_133348 item item-field_button_text item-option_1 item-int_5" >Подробности</a></p>
			</div>
		</div>
	</div>

	

	<div class="col_one_fourth  nobottommargin">
		<div class="feature-box center media-box fbox-bg">
			<div class="fbox-media">
				<a href="/dosudebnoe-uregulirovanie"><img class="image_fade" src="<?=$theme_path?>/files/ct_block_item_133348_6_5_image.jpg?_1607518394"></a>
			</div>
			<div class="fbox-desc">
				<h3 class="editable block_133348 item item-field_title item-option_704264 item-int_6">Досудебное урегулирование</h3>
				
				
				<p><a href="/dosudebnoe-uregulirovanie" class="btn button button-3d editable block_133348 item item-field_button_text item-option_1 item-int_6" >Подробности</a></p>
			</div>
		</div>
	</div>

	

	<div class="col_one_fourth col_last nobottommargin">
		<div class="feature-box center media-box fbox-bg">
			<div class="fbox-media">
				<a href="/ispolnitelnoe-proizvodstvo"><img class="image_fade" src="<?=$theme_path?>/files/ct_block_item_133348_7_5_image.jpg?_1607518394"></a>
			</div>
			<div class="fbox-desc">
				<h3 class="editable block_133348 item item-field_title item-option_704264 item-int_7">Исполнительное производство</h3>
				
				
				<p><a href="/ispolnitelnoe-proizvodstvo" class="btn button button-3d editable block_133348 item item-field_button_text item-option_1 item-int_7" >Подробности</a></p>
			</div>
		</div>
	</div>

	


    
        </div>
    </div>
</div>    
