<div class="section nobg dark nopadding" style="
background: url('<?=$theme_path?>/files/st_block_row_settings_133352_bg_HDATGi48.jpg?_1607584055') left 50% top 50% / cover no-repeat fixed !important; 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0.75);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        <div class="center">
    <h2 class="nott editable block_133352 item-option_268793 field_title" style="">О нас</h2>
    <p class="t300 editable block_133352 item-option_3 field_text">Текст о компании – это идеальная возможность для отстройки от конкурентов. Нужно оперировать фактами. Пусть их будет немного, но именно они будут демонстрировать уникальность вашей компании.<br>
<br>
Шаблон написания текста о компании:<br>
чем занимаемся; что у нас получается лучше всего; примеры наших работ; в чём отличие компании; наша команда в лицах; наша компания в цифрах; что о нас говорят клиенты; какие гарантии мы даём.</p>
    <p class="nobottommargin"><a href="/o-kompanii" class="button btn noleftmargin button-3d editable block_133352 item-option_1 field_button_text">Подробнее</a></p>
</div>    
        </div>
    </div>
</div>    
