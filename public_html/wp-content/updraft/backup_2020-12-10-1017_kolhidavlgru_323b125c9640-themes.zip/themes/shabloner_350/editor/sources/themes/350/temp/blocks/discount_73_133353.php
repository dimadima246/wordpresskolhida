<div class="section nobg  nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        <div class="promo promo-border promo-center">
	<h3 class="editable block_133353 item-option_296558 field_title">Торопитесь, скидка 20% до конца месяца!</h3>
	<span class="editable block_133353 item-option_3 field_text">Скидка — сумма, на которую снижается продажная цена товара, реализуемого покупателю. Исторически скидки появились и стали использоваться в условиях уличной торговли товарами, когда продавец в результате торга предоставлял скидку тому покупателю, который приобретает больше товаров.</span>
	<a href="/akcii" class="button button-xlarge button-rounded button-3d editable block_133353 item-option_1 field_button_text">Подробнее</a>
</div>    
        </div>
    </div>
</div>    
