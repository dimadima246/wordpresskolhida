<div class="section nobg  nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        
<div class="heading-block divcenter center" style="max-width: 600px">
<h2 class="notransform t600 mb-2 editable block_133349 item-option_431639 field_title" style="">Физическим лицам Все услуги</h2>

</div>




	<div class="col_one_fourth nobottommargin ">
		<div class="feature-box media-box">
			<div class="fbox-media">
				<img src="<?=$theme_path?>/files/ct_block_item_133349_742473_5_image.jpg?_1607518394">
			</div>
			<div class="fbox-desc center">
				<h3 class="editable block_133349 item item-field_title item-option_951063 item-int_742473">Наследственные споры</h3>
				
				
				<p class=""><a href="/nasledstvennye-spory" class="button btn button-3d editable block_133349 item item-field_button_text item-option_1 item-int_742473">Подробности</a></p>
			</div>
		</div>
	</div>
	

	<div class="col_one_fourth nobottommargin ">
		<div class="feature-box media-box">
			<div class="fbox-media">
				<img src="<?=$theme_path?>/files/ct_block_item_133349_1_5_image.jpg?_1607518394">
			</div>
			<div class="fbox-desc center">
				<h3 class="editable block_133349 item item-field_title item-option_951063 item-int_1">Автоюрист</h3>
				
				
				<p class=""><a href="/avtoiurist" class="button btn button-3d editable block_133349 item item-field_button_text item-option_1 item-int_1">Подробности</a></p>
			</div>
		</div>
	</div>
	

	<div class="col_one_fourth nobottommargin ">
		<div class="feature-box media-box">
			<div class="fbox-media">
				<img src="<?=$theme_path?>/files/ct_block_item_133349_2_5_image.jpg?_1607518394">
			</div>
			<div class="fbox-desc center">
				<h3 class="editable block_133349 item item-field_title item-option_951063 item-int_2">Трудовые споры</h3>
				
				
				<p class=""><a href="/trudovye-spory" class="button btn button-3d editable block_133349 item item-field_button_text item-option_1 item-int_2">Подробности</a></p>
			</div>
		</div>
	</div>
	

	<div class="col_one_fourth nobottommargin col_last">
		<div class="feature-box media-box">
			<div class="fbox-media">
				<img src="<?=$theme_path?>/files/ct_block_item_133349_3_5_image.jpg?_1607518394">
			</div>
			<div class="fbox-desc center">
				<h3 class="editable block_133349 item item-field_title item-option_951063 item-int_3">Семейные дела</h3>
				
				
				<p class=""><a href="/semeinye-dela" class="button btn button-3d editable block_133349 item item-field_button_text item-option_1 item-int_3">Подробности</a></p>
			</div>
		</div>
	</div>
	<div class="clear bottommargin"></div>

	<div class="col_one_fourth nobottommargin ">
		<div class="feature-box media-box">
			<div class="fbox-media">
				<img src="<?=$theme_path?>/files/ct_block_item_133349_4_5_image.jpg?_1607518394">
			</div>
			<div class="fbox-desc center">
				<h3 class="editable block_133349 item item-field_title item-option_951063 item-int_4">Споры с банками</h3>
				
				
				<p class=""><a href="/spory-s-bankami" class="button btn button-3d editable block_133349 item item-field_button_text item-option_1 item-int_4">Подробности</a></p>
			</div>
		</div>
	</div>
	

	<div class="col_one_fourth nobottommargin ">
		<div class="feature-box media-box">
			<div class="fbox-media">
				<img src="<?=$theme_path?>/files/ct_block_item_133349_5_5_image.jpg?_1607518394">
			</div>
			<div class="fbox-desc center">
				<h3 class="editable block_133349 item item-field_title item-option_951063 item-int_5">Споры со страховыми компаниями</h3>
				
				
				<p class=""><a href="/spory-so-strahovymi-kompaniiami" class="button btn button-3d editable block_133349 item item-field_button_text item-option_1 item-int_5">Подробности</a></p>
			</div>
		</div>
	</div>
	

	<div class="col_one_fourth nobottommargin ">
		<div class="feature-box media-box">
			<div class="fbox-media">
				<img src="<?=$theme_path?>/files/ct_block_item_133349_6_5_image.jpg?_1607518394">
			</div>
			<div class="fbox-desc center">
				<h3 class="editable block_133349 item item-field_title item-option_951063 item-int_6">Защита прав потребителей</h3>
				
				
				<p class=""><a href="/zashita-prav-potrebitelei" class="button btn button-3d editable block_133349 item item-field_button_text item-option_1 item-int_6">Подробности</a></p>
			</div>
		</div>
	</div>
	

	<div class="col_one_fourth nobottommargin col_last">
		<div class="feature-box media-box">
			<div class="fbox-media">
				<img src="<?=$theme_path?>/files/ct_block_item_133349_7_5_image.jpg?_1607518394">
			</div>
			<div class="fbox-desc center">
				<h3 class="editable block_133349 item item-field_title item-option_951063 item-int_7">Авторское право</h3>
				
				
				<p class=""><a href="/avtorskoe-pravo" class="button btn button-3d editable block_133349 item item-field_button_text item-option_1 item-int_7">Подробности</a></p>
			</div>
		</div>
	</div>
	
	




    
        </div>
    </div>
</div>    
