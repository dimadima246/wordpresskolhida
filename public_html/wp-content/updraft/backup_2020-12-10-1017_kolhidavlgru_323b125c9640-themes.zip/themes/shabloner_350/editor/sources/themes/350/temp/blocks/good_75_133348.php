<div class="section   nopadding" style="
 
margin-top:unset;
margin-bottom:unset;
">
    <div class="" style="background-color: rgba(0, 0, 0, 0);
padding-top:60px;
padding-bottom:60px;
    ">  
        <div class="container clearfix">
        
<div class="heading-block divcenter center" style="max-width: 600px">
<h2 class="notransform t600 mb-2 editable block_133348 item-option_358133 field_title" style="">Заголовок</h2>
<p class="editable block_133348 item-option_1 field_text">Съешь же ещё этих мягких французских булок да выпей чаю.</p>
</div>


<div class="row justify-content-between">


<div class="col-lg-6 ">
<div class="media row">
<img class="col-sm-5 p-5 p-sm-0 pr-sm-3" src="<?=$theme_path?>/files/ct_block_133348_item_66787_5.jpg?_1607584055" width="230">
<div class="col-sm-7 media-body">
<h3 class="mb-2"><a href="http://shabloner.ru/" class="editable block_133348 item item-field_title item-option_343342 item-int_66787">Заголовок</a></h3>
<p class="mb-3 text-black-50 editable block_133348 item item-field_text item-option_4 item-int_66787 nobottommargin">Съешь же ещё этих мягких французских булок да выпей чаю.</p>
<p class="mb-3 text-black-50 editable block_133348 item item-field_price item-option_3 item-int_66787 nobottommargin">30 000 руб.</p>
<a href="http://shabloner.ru/" class="button button-3d button-rounded t400 ls0 noleftmargin  topmargin-xs nott editable block_133348 item item-field_button_text item-option_1 item-int_66787">Подробности</a>
</div>
</div>
</div>


<div class="col-lg-6 mt-lg-0">
<div class="media row">
<img class="col-sm-5 p-5 p-sm-0 pr-sm-3" src="<?=$theme_path?>/files/ct_block_133348_item_1_5.jpg?_1607584055" width="230">
<div class="col-sm-7 media-body">
<h3 class="mb-2"><a href="http://shabloner.ru/" class="editable block_133348 item item-field_title item-option_343342 item-int_1">Заголовок</a></h3>
<p class="mb-3 text-black-50 editable block_133348 item item-field_text item-option_4 item-int_1 nobottommargin">Съешь же ещё этих мягких французских булок да выпей чаю.</p>
<p class="mb-3 text-black-50 editable block_133348 item item-field_price item-option_3 item-int_1 nobottommargin">30 000 руб.</p>
<a href="http://shabloner.ru/" class="button button-3d button-rounded t400 ls0 noleftmargin  topmargin-xs nott editable block_133348 item item-field_button_text item-option_1 item-int_1">Подробности</a>
</div>
</div>
</div>



</div>
    
        </div>
    </div>
</div>    
