
<div class="clearfix preview_edit preview_edit_bottom hidden" style="">
	<div class="container " style="">
		<div class="center row">
		<div class="col-sm-3"></div>
		<div class="col-sm-6">
		
		<button onclick="modal_dialog_open_constructor('choose_block_visual', 'page_id=<?=$_GET['page_id']?>&theme_id=<?=$theme_id?>&after_block_schema_id=<?=$block_schema_id?>&no_replace=1')" type="button" class="btn btn-outline-dark  btn-block">Добавить блок</div>
		
		</div>
		<div class="col-sm-3"></div>
	</div>
</div>
